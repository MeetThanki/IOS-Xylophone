//
//  ViewController.swift
//  Xylophone
//
//  Created by Meet Thanki on 24/06/19.
//  Copyright © 2019 Meet Thanki. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func notePressed(_ sender: UIButton) {
        print(sender.tag)
    }
    
}

